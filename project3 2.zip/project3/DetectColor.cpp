#include "DetectColor.h"

void DetectColor::on_trackbar(int, void*)
{//This function gets called whenever a
	// trackbar position is changed

}

string DetectColor::intToString(int number){

	std::stringstream ss;
	ss << number;
	return ss.str();
}

void DetectColor::drawObject(vector<Object> theObjects, Mat &frame){

	for (int i = 0; i < theObjects.size(); i++)
	{
		cv::circle(frame, cv::Point(theObjects.at(i).getXPos(), theObjects.at(i).getYPos()), 10, cv::Scalar(0, 0, 255));
		cv::putText(frame, intToString(theObjects.at(i).getXPos()) + " , " + intToString(theObjects.at(i).getYPos()), cv::Point(theObjects.at(i).getXPos(), theObjects.at(i).getYPos() + 20), 1, 1, Scalar(0, 255, 0));
		cv::putText(frame, theObjects.at(i).getType(), cv::Point(theObjects.at(i).getXPos(), theObjects.at(i).getYPos() - 30), 1, 2, theObjects.at(i).getColor());
	}
}

void DetectColor::morphOps(Mat &thresh){

	//create structuring element that will be used to "dilate" and "erode" image.
	//the element chosen here is a 3px by 3px rectangle
	Mat erodeElement = getStructuringElement( MORPH_RECT,Size(3,3));
	//dilate with larger element so make sure object is nicely visible
	Mat dilateElement = getStructuringElement( MORPH_RECT,Size(8,8));

	erode(thresh,thresh,erodeElement);
	erode(thresh,thresh,erodeElement);

	dilate(thresh,thresh,dilateElement);
	dilate(thresh,thresh,dilateElement);
}

void DetectColor::trackFilteredObject(Object theObject, Mat threshold, Mat HSV, Mat &cameraFeed){

	vector <Object> objects;
	Mat temp;
	threshold.copyTo(temp);
	//these two vectors needed for output of findContours
	vector< vector<Point> > contours;
	vector<Vec4i> hierarchy;
	//find contours of filtered image using openCV findContours function
	findContours(temp, contours, hierarchy, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	//use moments method to find our filtered object
	double refArea = 0;
	bool objectFound = false;
	if (hierarchy.size() > 0) {
		int numObjects = hierarchy.size();
		//if number of objects greater than MAX_NUM_OBJECTS we have a noisy filter
		if (numObjects < MAX_NUM_OBJECTS)
		{
			for (int index = 0; index >= 0; index = hierarchy[index][0]) 
			{

				Moments moment = moments((cv::Mat)contours[index]);
				double area = moment.m00;

				//if the area is less than 20 px by 20px then it is probably just noise
				//if the area is the same as the 3/2 of the image size, probably just a bad filter
				//we only want the object with the largest area so we safe a reference area each
				//iteration and compare it to the area in the next iteration.
				if (area > 15000)
				{
					Object object;
					object.setXPos(moment.m10 / area);
					object.setYPos(moment.m01 / area);
					object.setType(theObject.getType());
					object.setColor(theObject.getColor());
					objects.push_back(object);
					objectFound = true;
				}

				else objectFound = false;
			}
			//let user know you found an object
			if (objectFound == true){
				//draw object location on screen
				drawObject(objects, cameraFeed);
			}

		}
	}
}

int DetectColor::detect(Mat cameraFeed)
{
	//if we would like to calibrate our filter values, set to true.
	bool calibrationMode = true;

	Mat threshold;
	Mat HSV;

	//convert frame from BGR to HSV colorspace
	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);

	//create some temp fruit objects so that
	//we can use their member functions/information
	Object white("black"), black("white"),blue("blue"), yellow("yellow"), red("red"), green("green");

	//first find blue objects
	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);
	inRange(HSV, white.getHSVmin(), white.getHSVmax(), threshold);
	morphOps(threshold);
	trackFilteredObject(white, threshold, HSV, cameraFeed);

	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);
	inRange(HSV, black.getHSVmin(), black.getHSVmax(), threshold);
	morphOps(threshold);
	trackFilteredObject(black, threshold, HSV, cameraFeed);

	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);
	inRange(HSV, blue.getHSVmin(), blue.getHSVmax(), threshold);
	morphOps(threshold);
	trackFilteredObject(blue, threshold, HSV, cameraFeed);
	//then yellows
	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);
	inRange(HSV, yellow.getHSVmin(), yellow.getHSVmax(), threshold);
	morphOps(threshold);
	trackFilteredObject(yellow, threshold, HSV, cameraFeed);
	//then reds
	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);
	inRange(HSV, red.getHSVmin(), red.getHSVmax(), threshold);
	morphOps(threshold);
	trackFilteredObject(red, threshold, HSV, cameraFeed);
	//then greens
	cvtColor(cameraFeed, HSV, COLOR_BGR2HSV);
	inRange(HSV, green.getHSVmin(), green.getHSVmax(), threshold);
	morphOps(threshold);
	trackFilteredObject(green, threshold, HSV, cameraFeed);

	//show frames
	namedWindow("Car Counter", WINDOW_NORMAL);

	imshow("Car Counter", cameraFeed);
	
	waitKey(1);
	return 0;
}
